package com.example.app;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
 
public class Activity1 extends Activity {
    private Button btnVoltar;
    private EditText txtParametroEnviar;
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity1);
 
       
        txtParametroEnviar = (EditText) findViewById(R.id.txtParametroEnviarActivity1);
        btnVoltar = (Button) findViewById(R.id.btnVoltar);
        btnVoltar.setOnClickListener(new View.OnClickListener() {
 
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
 
    @Override
    public void onBackPressed() {
        Intent it = new Intent();
        it.putExtra("PARAM_ACTIVITY1", txtParametroEnviar.getText().toString());
        setResult(1, it);
        super.onBackPressed();
    }
}