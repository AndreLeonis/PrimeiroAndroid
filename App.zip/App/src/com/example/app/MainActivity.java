package com.example.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
 
public class MainActivity extends Activity {
    private EditText txtParam1, txtParam2;
    private Button btActivity2, btActivity1;
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtParam1 = (EditText) findViewById(R.id.txtParamRecebidoActivity2);
 
        txtParam2 = (EditText) findViewById(R.id.txtParamEnviarActivity2);
        btActivity1 = (Button) findViewById(R.id.btActivity1);
        btActivity1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(MainActivity.this, Activity1.class);
                it.putExtra("PARAM_ACTIVITY1", txtParam1
                        .getText().toString());
                it.putExtra("PARAM_ACTIVITY1", txtParam2
                        .getText().toString());
                
                startActivityForResult(it, 1);
            }
        });
        
        btActivity2 = (Button)findViewById(R.id.btActivity2);
        btActivity2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				   Intent it = new Intent(MainActivity.this, Activity2.class);
	                it.putExtra("PARAM_PRINCIPAL", txtParam1
	                        .getText().toString());
	                it.putExtra("PARAM_PRINCIPAL", txtParam2
	                        .getText().toString());
	                
	                startActivityForResult(it, 2);
	            }
		});
    }
 
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
        case 1:
            txtParam1.setText(data.getExtras().getString(
                    "PARAM_ACTIVITY1"));
            break;
        case 2:
            txtParam2.setText(data.getExtras().getString(
                    "PARAM_ACTIVITY2"));
            break;
        
        }
        
        super.onActivityResult(requestCode, resultCode, data);
    }
 
}